###### based on [dpage/pgadmin4]

# pgAdmin 4

[pgAdmin4](https://www.pgadmin.org/) is the leading Open Source management tool for Postgres, the world’s most advanced Open Source database. pgAdmin4 is designed to meet the needs of both novice and experienced Postgres users alike, providing a powerful graphical interface that simplifies the creation, maintenance and use of database objects.

## Prerequisites

* Kubernetes 1.19+
* Helm 3.7+

## TL;DR

```console
helm repo add runix https://helm.runix.net
helm install pgadmin4 runix/pgadmin4
```

## Introduction

This chart bootstraps a [pgAdmin4](https://www.pgadmin.org/) deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Install the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release runix/pgadmin4
```

The command deploys pgAdmin4 on the Kubernetes cluster in the default configuration. The configuration section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Upgrading

### To 1.67.0

> **Breaking for `workload.kind: StatefulSet` only.** Deployment installs, the default, upgrade as usual.

Before 1.67.0, the StatefulSet `volumeClaimTemplates` carried the chart and app version labels. Kubernetes does not allow changes to `volumeClaimTemplates`, so every upgrade of a StatefulSet install failed with `spec.volumeClaimTemplates: ... field is immutable`. From 1.67.0 on, `volumeClaimTemplates` only carry labels that never change.

To upgrade a StatefulSet install to 1.67.0, delete the StatefulSet without deleting its pods and PVCs, then upgrade:

```console
kubectl delete statefulset -n <namespace> -l app.kubernetes.io/instance=<release> --cascade=orphan
helm upgrade -n <namespace> <release> runix/pgadmin4 --version 1.67.0
```

The new StatefulSet adopts the running pod and the existing PVC, so your data stays. You only need this step once.

## Good to know

### Default login and server definitions apply on first start only

pgAdmin reads `env.email`, the default password, and `serverDefinitions` only when it creates its configuration database, on the first start with an empty `/var/lib/pgadmin`. With `persistentVolume.enabled`, later changes to these values have no effect on the existing volume. Change the login in pgAdmin itself, or start over with a new volume.

### Certificates outside pgAdmin storage

In server mode, pgAdmin only reads certificate files, such as `sslrootcert`, from its storage directory. To use certificates that something else mounts at a fixed path, for example autocert at `/var/run/autocert.step.sm`, register that directory with `PGADMIN_CONFIG_SHARED_STORAGE` and refer to files as `<name>:/<file>`. See [`examples/certificates-from-another-volume.yaml`](examples/certificates-from-another-volume.yaml).

### Running behind more than one proxy

pgAdmin trusts the `X-Forwarded-*` headers of one proxy. Behind two, such as a cloud load balancer in front of the ingress controller, it builds `http://` URLs and OAuth2 providers reject the redirect URI. Set `PGADMIN_CONFIG_PROXY_X_FOR_COUNT`, `PGADMIN_CONFIG_PROXY_X_PROTO_COUNT`, and `PGADMIN_CONFIG_PROXY_X_HOST_COUNT` to the number of proxies, as in [`examples/behind-multiple-proxies.yaml`](examples/behind-multiple-proxies.yaml).

## Hardening

To run pgAdmin under the Kubernetes `restricted` [Pod Security Standard](https://kubernetes.io/docs/concepts/security/pod-security-standards/), use:

```yaml
containerPorts:
  http: 8080
containerSecurityContext:
  enabled: true
  allowPrivilegeEscalation: false
  runAsNonRoot: true
  readOnlyRootFilesystem: true
  capabilities:
    drop:
      - ALL
  seccompProfile:
    type: RuntimeDefault
```

Without privilege escalation, pgAdmin cannot bind port 80, so it listens on `containerPorts.http` instead. The Service keeps port 80 and targets the container port by name. With `readOnlyRootFilesystem`, the chart mounts emptyDirs at `/tmp` and `/var/log/pgadmin` unless `extraVolumeMounts` already covers those paths. CI installs and upgrades these values on every change (`ci/hardened-values.yaml`).

## Uninstall the Chart

To uninstall/delete the `my-release` deployment:

```console
helm delete --purge my-release
```

The command removes nearly all the Kubernetes components associated with the chart and deletes the release.

## Configuration

| Parameter | Description | Default |
| --------- | ----------- | ------- |
| `global.imageRegistry` | Global image pull registry for all images | `""` |
| `global.imagePullSecrets` | Global image pull secrets, support both full format (- name: secret) and short format (- secret) | `[]` |
| `nameOverride` | Override the chart name used in resource names and labels | `""` |
| `fullnameOverride` | Override the full resource name | `""` |
| `workload.kind` | Workload type (Deployment or StatefulSet) | `Deployment` |
| `replicaCount` | Number of pgadmin4 replicas | `1` |
| `image.registry` | Docker image registry | `docker.io` |
| `image.repository` | Docker image | `dpage/pgadmin4` |
| `image.tag` | Docker image tag | `""` |
| `image.pullPolicy` | Docker image pull policy | `IfNotPresent` |
| `imagePullSecrets` | Docker image pull secrets | `[]` |
| `annotations` | Deployment Annotations | `{}` |
| `revisionHistoryLimit` | The number of old history to retain to allow rollback | `10` |
| `commonLabels` | Add labels to all the deployed resources | `{}` |
| `priorityClassName` | Deployment priorityClassName | `""` |
| `command` | Deployment command override | `""` |
| `args` | Deployment arguments override | `[]` |
| `service.type` | Service type (ClusterIP, NodePort or LoadBalancer) | `ClusterIP` |
| `service.clusterIP` | Service type Cluster IP | `""` |
| `service.loadBalancerIP` | Service Load Balancer IP | `""` |
| `service.annotations` | Service Annotations | `{}` |
| `service.port` | Service port | `80` |
| `service.portName` | Name of the port on the service | `http` |
| `service.targetPort` | Container port the Service targets, a number or a port name. Empty means the port named `service.portName` | `""` |
| `service.nodePort` | Kubernetes service nodePort | `` |
| `serviceAccount.create` | Creates a ServiceAccount for the pod. | `false` |
| `serviceAccount.annotations` | Annotations to add to the service account. | `{}` |
| `serviceAccount.name` | The name of the service account. Otherwise uses the fullname. | `` |
| `serviceAccount.automountServiceAccountToken` | Opt out of API credential automounting. | `false` |
| `hostAliases` | Add entries to Pod /etc/hosts | `` |
| `strategy` | Specifies the strategy used to replace old Pods by new ones | `{}` |
| `serverDefinitions.enabled` | Enables Server Definitions | `false` |
| `serverDefinitions.resourceType` | The type of resource to deploy server definitions (either `ConfigMap` or `Secret`) | `ConfigMap` |
| `serverDefinitions.existingConfigmap` | The name of a configMap containing Server Definitions. Only used when `serverDefinitions.resourceType` is `ConfigMap` | `""` |
| `serverDefinitions.existingSecret` | The name of a Secret containing Server Definitions. Only used when `serverDefinitions.resourceType` is `Secret` | `""` |
| `serverDefinitions.useStringData` | When `resourceType` = `Secret` put raw JSON under `stringData:` instead of base-64 under `data:`. Useful for debugging | `false` |
| `serverDefinitions.annotations` | Annotations for ConfigMap or Secret, if you are not using existing resources. Useful for cluster webhooks | `{}` |
| `serverDefinitions.servers` | Pre-configured server parameters | `{}` |
| `preferences.enabled` | Specify if to create preferences configmap and mount it | `false` |
| `preferences.existingConfigMap` | The name of a configMap containing your Preferences | `""` |
| `preferences.data` | Preferences Data | `{}` |
| `networkPolicy.enabled` | Enables Network Policy | `true` |
| `podDisruptionBudget.enabled` | Creates a PodDisruptionBudget | `false` |
| `podDisruptionBudget.minAvailable` | Pods that must stay available during voluntary disruptions | `1` |
| `podDisruptionBudget.maxUnavailable` | Pods that may be unavailable at once. Takes precedence over `minAvailable` | `nil` |
| `httpRoute.labels` | Additional labels to add to the generated HTTPRoute resource metadata. | `{}` |
| `httpRoute.annotations` | Key-value map for controller-specific metadata | `{}` |
| `httpRoute.enabled` | Switches from standard Ingress to Gateway API HTTPRoute resource generation | `false` |
| `httpRoute.hostnames` | FQDNs for Layer 7 matching. If empty, matches all hostnames on the parent Gateway listener | `[]` |
| `httpRoute.matches` | Core routing rules (path/headers) and backendRefs; evaluated in order until a match occurs | `[]` |
| `httpRoute.parentRefs` | Binds this route to specific Gateway resources (name/namespace), enabling the data plane attachment | `[]` |
| `ingress.enabled` | Enables Ingress | `false` |
| `ingress.annotations` | Ingress annotations | `{}` |
| `ingress.labels` | Custom labels | `{}` |
| `ingress.ingressClassName` | Ingress Class Name. MAY be required for Kubernetes versions >= 1.18 | `""` |
| `ingress.hosts.host` | Ingress accepted hostname | `nil` |
| `ingress.hosts.paths` | Ingress paths list | `[]` |
| `ingress.hosts.paths.path` | Ingress accepted path | `/` |
| `ingress.hosts.paths.pathType` | Ingress type of path | `Prefix` |
| `ingress.tls` | Ingress TLS configuration | `[]` |
| `istioIngress.enabled` | Enable Istio Gateway instead of Ingress | `false` |
| `istioIngress.selector` | Label selector for Istio Ingress Gateway pods | `""` |
| `istioIngress.endpoints` | Hosts served by Istio Gateway | `[""]` |
| `istioIngress.tls.enabled` | Enable TLS for Istio gateway | `false` |
| `istioIngress.tls.secretCertName` | TLS certificate secret name | `"my-istio-tls-secret"` |
| `istioIngress.gateway.enabled` | Enable Istio Gateway resource | `false` |
| `istioIngress.gateway.ports` | Istio gateway ports configuration | `{http: {...}, https: {...}}` |
| `istioIngress.virtualService.enabled` | Enable Istio VirtualService | `false` |
| `istioIngress.virtualService.gateway` | VirtualService gateway name | `""` |
| `istioIngress.virtualService.config` | VirtualService routing config | `{}` |
| `extraConfigmapMounts` | Additional configMap volume mounts for pgadmin4 pod | `[]` |
| `extraSecretMounts` | Additional secret volume mounts for pgadmin4 pod | `[]` |
| `extraVolumes` | Additional volumes for the pgadmin4 pod | `[]` |
| `extraVolumeMounts` | Additional volume mounts for the pgadmin4 container | `[]` |
| `extraContainers` | Sidecar containers to add to the pgadmin4 pod | `"[]"` |
| `existingSecret` | The name of an existing secret containing the pgadmin4 default password and, optionally, Server Definitions. | `""` |
| `secretKeys.pgadminPasswordKey` | Name of key in existing secret to use for default pgadmin credentials. Only used when `existingSecret` is set. | `"password"` |
| `extraInitContainers` | Sidecar init containers to add to the pgadmin4 pod | `"[]"` |
| `env.email` | pgAdmin4 default email. Needed chart reinstall for apply changes | `chart@domain.com` |
| `env.password` | pgAdmin4 default password. Needed chart reinstall for apply changes | `SuperSecret` |
| `pgpass.existingSecret` | Existing Secret with a pgpass file. An init container copies it into the pod with mode 0600 and the chart sets `PGPASSFILE`, unless `env.pgpassfile` is set | `""` |
| `pgpass.key` | Key in `pgpass.existingSecret` that holds the pgpass file | `pgpass` |
| `env.pgpassfile` | Path to pgpassfile (optional). Needed chart reinstall for apply changes | `` |
| `env.enhanced_cookie_protection` | Allows pgAdmin4 to create session cookies based on IP address | `"False"` |
| `env.contextPath` | Context path for accessing pgadmin (optional) | `` |
| `envVarsFromConfigMaps` | Array of ConfigMap names to load as environment variables | `[]` |
| `envVarsFromSecrets` | Array of Secret names to load as environment variables | `[]` |
| `envVarsExtra` | Array of arbitrary environment variable definitions (e.g., for fetching from Kubernetes Secrets) | `[]` |
| `persistentVolume.enabled` | If true, pgAdmin4 will create a Persistent Volume Claim | `true` |
| `persistentVolume.accessModes` | Persistent Volume access modes | `[ReadWriteOnce]` |
| `persistentVolume.size` | Persistent Volume size | `10Gi` |
| `persistentVolume.storageClass` | Persistent Volume Storage Class | `unset` |
| `persistentVolume.existingClaim` | Persistent Volume existing claim name | `unset` |
| `persistentVolume.subPath` | Subdirectory of the volume to mount at | `unset` |
| `securityContext` | Custom [pod security context](https://kubernetes.io/docs/tasks/configure-pod-container/security-context/) for pgAdmin4 pod | `` |
| `containerSecurityContext` | Custom [security context](https://kubernetes.io/docs/tasks/configure-pod-container/security-context/) for pgAdmin4 container | `` |
| `livenessProbe` | [liveness probe](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/) initial delay and timeout | `` |
| `startupProbe` | [startup probe](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/) initial delay and timeout | `` |
| `readinessProbe` | [readiness probe](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/) initial delay and timeout | `` |
| `VolumePermissions.enabled` | Enables init container that changes volume permissions in the data directory | `false` |
| `extraDeploy` | List of extra manifests to deploy | `[]` |
| `containerPorts.http` | Sets http port inside pgadmin container | `80` |
| `resources` | CPU/memory resource requests/limits | `{}` |
| `autoscaling.enabled` | Enables Autoscaling | `false` |
| `autoscaling.minReplicas` | Minimum amount of Replicas | `1` |
| `autoscaling.maxReplicas` | Maximum amount of Replicas | `100` |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU Utilization in percentage | `80` |
| `autoscaling.targetMemoryUtilizationPercentage` | Target Memory Utilization in percentage | `nil` |
| `autoscaling.behavior` | HPA scaling policies and stabilization windows (`spec.behavior`) | `{}` |
| `nodeSelector` | Node labels for pod assignment | `{}` |
| `tolerations` | Node tolerations for pod assignment | `[]` |
| `affinity` | Node affinity for pod assignment | `{}` |
| `topologySpreadConstraints` | Topology spread constraints for pods | `[]` |
| `dnsPolicy` | DNS policy for pods | `""` |
| `dnsConfig` | DNS config for pods | `{}` |
| `podAnnotations` | Annotations for pod | `{}` |
| `templatedPodAnnotations` | Templated annotations for pod | `{}` |
| `podLabels` | Labels for pod | `{}` |
| `namespace` | Namespace where to deploy resources | `null` |
| `init.resources` | Init container CPU/memory resource requests/limits | `{}` |
| `test.enabled` | Enables test | `true` |
| `test.hookDeletePolicy` | [Hook deletion policy](https://helm.sh/docs/topics/charts_hooks/#hook-deletion-policies) for the test Pod. Use `before-hook-creation` to keep the Pod for `helm test --logs` | `hook-succeeded` |
| `test.image.registry` | Docker image registry for test | `docker.io` |
| `test.image.repository` | Docker image for test | `busybox` |
| `test.image.tag` | Docker image tag for test | `1.38.0` |
| `test.resources` | CPU/memory resource requests/limits for test | `{}` |
| `test.securityContext` | Custom [security context](https://kubernetes.io/docs/tasks/configure-pod-container/security-context/) for test Pod | `` |
| `test.containerSecurityContext` | Custom [pod security context](https://kubernetes.io/docs/tasks/configure-pod-container/security-context/) for test pod | `{readOnlyRootFilesystem: true, allowPrivilegeEscalation: false, capabilities: {drop: [ALL]}, seccompProfile: {type: RuntimeDefault}}` |

> **Note**: The values for `extraConfigmapMounts.[].configMap` and `extraSecretMounts.[].secret` can be either a simple string or a template string. It will be resolved automatically.

> **Note**: The TLS secrets need to be created manually in the istio-ingress namespace (considering your ingress gateway is installed in the istio-ingress namespace) and can then be referenced in `istio.tls.secretCertName`.

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example:

```console
helm install my-release runix/pgadmin4 \
  --set env.password=SuperSecret
```

Alternatively, a YAML file that specifies the values for the parameters can be
provided while installing the chart. For example:

```console
helm install my-release runix/pgadmin4 -f values.yaml
```

> **Tip**: You can use the default [values.yaml](https://github.com/rowanruseler/helm-charts/blob/main/charts/pgadmin4/values.yaml) and look on [examples](https://github.com/rowanruseler/helm-charts/blob/main/charts/pgadmin4/examples/).

[dpage/pgadmin4]: https://hub.docker.com/r/dpage/pgadmin4
