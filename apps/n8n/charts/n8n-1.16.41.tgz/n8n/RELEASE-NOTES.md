# Changelog

- **Changed**: Update n8nio/n8n image version to 2.21.4
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency postgresql from 18.6.4 to 18.6.7
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
