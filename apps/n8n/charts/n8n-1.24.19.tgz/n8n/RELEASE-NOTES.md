# Changelog

- **Changed**: Update n8nio/n8n image version to 2.31.7
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 27.0.17 to 27.0.18
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.8.0 to 18.8.1
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
