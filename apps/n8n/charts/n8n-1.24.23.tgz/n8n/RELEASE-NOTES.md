# Changelog

- **Changed**: Update n8nio/n8n image version to 2.33.4
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 27.0.18 to 28.0.0
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.8.4 to 18.8.6
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
