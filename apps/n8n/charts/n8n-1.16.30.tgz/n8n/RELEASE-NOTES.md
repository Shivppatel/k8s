# Changelog

- **Changed**: Update n8nio/n8n image version to 2.11.3
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 25.3.0 to 25.3.2
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.4.0 to 18.5.6
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
