# Changelog

- **Changed**: Update n8nio/n8n image version to 2.39.8
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.0.15 to 28.2.2
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.10.0 to 18.11.5
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
