# Changelog

- **Changed**: Update n8nio/n8n image version to 2.22.4
    - [Upstream Project](https://github.com/n8n-io/n8n)
