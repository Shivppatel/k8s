# Changelog

- **Changed**: Update n8nio/n8n image version to 2.16.0
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 25.3.9 to 25.3.11
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.5.14 to 18.5.17
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
