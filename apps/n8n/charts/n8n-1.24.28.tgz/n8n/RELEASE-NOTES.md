# Changelog

- **Changed**: Update n8nio/n8n image version to 2.34.6
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.0.2 to 28.0.5
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.8.8 to 18.8.9
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
