# Changelog

- **Changed**: Update n8nio/n8n image version to 2.33.5
    - [Upstream Project](https://github.com/n8n-io/n8n)
