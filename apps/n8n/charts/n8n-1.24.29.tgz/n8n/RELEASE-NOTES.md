# Changelog

- **Changed**: Update n8nio/n8n image version to 2.35.3
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.0.5 to 28.0.7
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.8.9 to 18.8.12
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
