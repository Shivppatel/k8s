# Changelog

- **Changed**: Update n8nio/n8n image version to 2.38.4
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency postgresql from 18.9.0 to 18.10.0
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
