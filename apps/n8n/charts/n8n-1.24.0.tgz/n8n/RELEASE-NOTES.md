# Changelog

- **Added**: Add log.format option to control N8N_LOG_FORMAT (text or json, default text)
  
- **Fixed**: Change log.file.location default to absolute path /home/node/.n8n/logs/n8n.log so file logging works with readOnlyRootFilesystem enabled
    - [GitHub Issue](https://github.com/community-charts/helm-charts/issues/521)
- **Fixed**: Mount emptyDir at /home/node/.npm so npm can write temp files and logs when readOnlyRootFilesystem is enabled
    - [GitHub Issue](https://github.com/community-charts/helm-charts/issues/521)
