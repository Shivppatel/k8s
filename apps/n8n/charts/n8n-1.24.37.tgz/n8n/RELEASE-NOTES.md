# Changelog

- **Changed**: Update n8nio/n8n image version to 2.37.9
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.0.12 to 28.0.15
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.8.14 to 18.8.17
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
