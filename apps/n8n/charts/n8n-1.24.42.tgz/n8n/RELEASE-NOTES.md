# Changelog

- **Changed**: Update n8nio/n8n image version to 2.40.5
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.2.2 to 28.2.3
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.11.5 to 18.11.6
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
