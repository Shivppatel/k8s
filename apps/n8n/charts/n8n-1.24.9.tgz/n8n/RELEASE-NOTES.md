# Changelog

- **Changed**: Update n8nio/n8n image version to 2.29.9
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency postgresql from 18.7.12 to 18.7.13
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
