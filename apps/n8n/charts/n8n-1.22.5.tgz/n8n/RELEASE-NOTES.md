# Changelog

- **Fixed**: Set NPM_CONFIG_CACHE env var in main container to allow community package installation with readOnlyRootFilesystem enabled
    - [GitHub Issue](https://github.com/community-charts/helm-charts/issues/508)
  - [GitHub Issue](https://github.com/community-charts/community-charts.github.io/issues/102)
- **Fixed**: Fix community node packages not available to n8n process in external task runner mode and add --ignore-scripts to prevent postinstall script failures
  
- **Added**: Add optional PVC persistence for community node packages via nodes.external.persistence
  
- **Fixed**: Route community package installs into the main/worker PVC when its mountPath already covers /home/node/.n8n/nodes, eliminating a redundant separate volume
  
- **Fixed**: Fix worker PVC not created when worker.count > 1 with ReadWriteMany access mode
  
- **Fixed**: Fix community packages sharing a ReadWriteOnce PVC across StatefulSet replicas when forceToUseStatefulset is true
  
