# Changelog

- **Changed**: Update n8nio/n8n image version to 2.31.6
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 27.0.15 to 27.0.17
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
