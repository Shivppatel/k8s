# Changelog

- **Changed**: Update n8nio/n8n image version to 2.27.5
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 27.0.12 to 27.0.13
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.7.8 to 18.7.9
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
