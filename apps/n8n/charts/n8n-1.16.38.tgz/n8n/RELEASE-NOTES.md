# Changelog

- **Changed**: Update n8nio/n8n image version to 2.18.4
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 25.3.12 to 25.4.1
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.6.1 to 18.6.2
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
