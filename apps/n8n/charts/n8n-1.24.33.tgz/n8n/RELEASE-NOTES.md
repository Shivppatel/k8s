# Changelog

- **Changed**: Update n8nio/n8n image version to 2.36.7
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.0.7 to 28.0.10
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.8.12 to 18.8.13
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
