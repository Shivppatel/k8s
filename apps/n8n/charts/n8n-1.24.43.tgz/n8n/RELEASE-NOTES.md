# Changelog

- **Changed**: Update n8nio/n8n image version to 2.41.6
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.2.3 to 28.3.1
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.11.6 to 18.12.4
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
