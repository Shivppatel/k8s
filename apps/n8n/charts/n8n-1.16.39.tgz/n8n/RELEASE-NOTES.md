# Changelog

- **Changed**: Update n8nio/n8n image version to 2.19.2
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 25.4.1 to 25.5.1
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
