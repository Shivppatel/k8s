# Changelog

- **Changed**: Update n8nio/n8n image version to 2.26.8
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Fixed**: Fix broken screenshot URL(s) in n8n chart
  
