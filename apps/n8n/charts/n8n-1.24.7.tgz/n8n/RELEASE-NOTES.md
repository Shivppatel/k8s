# Changelog

- **Changed**: Update n8nio/n8n image version to 2.29.7
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 27.0.13 to 27.0.14
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.7.11 to 18.7.12
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
