# Changelog

- **Changed**: Update n8nio/n8n image version to 2.32.6
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency postgresql from 18.8.1 to 18.8.4
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
