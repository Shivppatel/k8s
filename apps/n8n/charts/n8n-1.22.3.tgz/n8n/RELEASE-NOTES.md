# Changelog

- **Changed**: Update n8nio/n8n image version to 2.26.4
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 27.0.4 to 27.0.10
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
- **Changed**: Update dependency postgresql from 18.7.3 to 18.7.5
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
