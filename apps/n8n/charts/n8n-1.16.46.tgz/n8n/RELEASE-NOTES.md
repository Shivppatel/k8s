# Changelog

- **Changed**: Update n8nio/n8n image version to 2.23.2
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 25.5.3 to 27.0.0
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
