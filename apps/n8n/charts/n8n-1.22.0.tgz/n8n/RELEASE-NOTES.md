# Changelog

- **Fixed**: Remove deprecated N8N_RUNNERS_ENABLED environment variable (safe since n8n 1.69+)
    - [Issue #412](https://github.com/community-charts/helm-charts/issues/412)
  - [Issue #436](https://github.com/community-charts/helm-charts/issues/436)
  - [Issue #474](https://github.com/community-charts/helm-charts/issues/474)
- **Fixed**: Use n8nio/runners image for external task runner sidecar instead of n8nio/n8n
    - [Issue #329](https://github.com/community-charts/helm-charts/issues/329)
  - [Issue #434](https://github.com/community-charts/helm-charts/issues/434)
- **Fixed**: Skip external task runner sidecar on main pod when worker.mode is queue
    - [Issue #414](https://github.com/community-charts/helm-charts/issues/414)
- **Fixed**: Rename runner sidecar port from http to runner-health to eliminate duplicate port name warning
  
- **Fixed**: Move N8N_RUNNERS_STDLIB_ALLOW and N8N_RUNNERS_EXTERNAL_ALLOW to task-broker configmap so n8n enforces the correct Python security policy
  
- **Added**: Add Python runner support via nodes.python.enabled flag (requires n8n 1.111.0+ and taskRunners.mode=external)
  
- **Added**: Add nodes.python.external.packages to install Python packages via uv before the runner starts; N8N_RUNNERS_EXTERNAL_ALLOW is derived automatically from the package list
  
- **Added**: Add optional PVC persistence for Python installed packages via nodes.python.persistence; ReadWriteMany required when HPA or multi-node Deployment is used
  
- **Added**: Add pypiRegistry support for installing Python packages from a private PyPI index (URL-only via UV_DEFAULT_INDEX or uv.toml config file via UV_CONFIG_FILE; mirrors npmRegistry pattern)
  
