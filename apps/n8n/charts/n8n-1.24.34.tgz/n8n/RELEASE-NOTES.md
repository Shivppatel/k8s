# Changelog

- **Changed**: Update n8nio/n8n image version to 2.36.8
    - [Upstream Project](https://github.com/n8n-io/n8n)
- **Changed**: Update dependency redis from 28.0.10 to 28.0.12
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/redis)
