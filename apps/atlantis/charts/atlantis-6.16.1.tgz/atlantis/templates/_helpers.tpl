{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "atlantis.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Render a value that may be either a plain structure or a string containing
Go template directives. Lets extension points (extraContainers, extraVolumes,
dnsConfig, ...) pull in helpers/values from a parent or library chart while
staying backward-compatible with plain-YAML values.
Usage:
  {{- include "atlantis.tplvalues.render" (dict "value" .Values.extraContainers "context" $) | nindent 8 }}
*/}}
{{- define "atlantis.tplvalues.render" -}}
{{- if kindIs "string" .value }}
{{- tpl .value .context }}
{{- else }}
{{- tpl (toYaml .value) .context }}
{{- end }}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "atlantis.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "atlantis.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "atlantis.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "atlantis.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Defines the scheme (http or https) of the Atlantis service
*/}}
{{- define "atlantis.url.scheme" -}}
{{- if .Values.tlsSecretName -}}
https
{{- else -}}
http
{{- end -}}
{{- end -}}

{{/*
Defines the internal kubernetes address to Atlantis
*/}}
{{- define "atlantis.url" -}}
{{ template "atlantis.url.scheme" . }}://{{ template "atlantis.fullname" . }}.{{ .Release.Namespace }}.svc.cluster.local:{{ .Values.service.port }}
{{- end -}}

{{/*
Generates secret-webhook name
*/}}
{{- define "atlantis.vcsSecretName" -}}
{{- if .Values.vcsSecretName -}}
    {{ .Values.vcsSecretName }}
{{- else -}}
    {{ template "atlantis.fullname" . }}-webhook
{{- end -}}
{{- end -}}

{{/*
Generates AWS Secret name
*/}}
{{- define "atlantis.awsSecretName" -}}
{{- if .Values.awsSecretName -}}
    {{ .Values.awsSecretName }}
{{- else -}}
    {{ template "atlantis.fullname" . }}-aws
{{- end -}}
{{- end -}}

{{/*
Generates Basic Auth name
*/}}
{{- define "atlantis.basicAuthSecretName" -}}
{{- if .Values.basicAuthSecretName -}}
    {{ .Values.basicAuthSecretName }}
{{- else -}}
    {{ template "atlantis.fullname" . }}-basic-auth
{{- end -}}
{{- end -}}

{{/*
Generates API Secret name
*/}}
{{- define "atlantis.apiSecretName" -}}
{{- if .Values.apiSecretName -}}
    {{ .Values.apiSecretName }}
{{- else -}}
    {{ template "atlantis.fullname" . }}-api
{{- end -}}
{{- end -}}

{{/*
Generates Redis Secret name
*/}}
{{- define "atlantis.redisSecretName" -}}
{{- if .Values.redisSecretName -}}
    {{ .Values.redisSecretName }}
{{- else -}}
    {{ template "atlantis.fullname" . }}-redis
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "atlantis.labels" -}}
app: {{ template "atlantis.name" . }}
chart: {{ template "atlantis.chart" . }}
helm.sh/chart: {{ template "atlantis.chart" . }}
release: {{ .Release.Name }}
heritage: {{ .Release.Service }}
{{- if .Values.commonLabels}}
{{ toYaml .Values.commonLabels }}
{{- end }}
{{- end -}}

{{/*
Define PATH environment variable that will be used system-wide.
*/}}
{{- define "atlantis.pathEnvironmentVariable" -}}
{{- if .Values.extraPath }}
{{- printf "%s:" .Values.extraPath -}}
{{- end -}}
{{- if .Values.initConfig.sharedDir }}
{{- printf "%s:" .Values.initConfig.sharedDir -}}
{{- end -}}
{{- printf "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" }}
{{- end -}}

{{/*
Sets the container port based on the defined values.
*/}}
{{- define "atlantis.containerPort" -}}
{{- default .Values.service.targetPort .Values.containerPort  }}
{{- end -}}

{{/*
Render an Ingress service backend port as either a named port or a numbered port.
*/}}
{{- define "atlantis.ingressServicePort" -}}
{{- if kindIs "string" . -}}
name: {{ . | quote }}
{{- else -}}
number: {{ . }}
{{- end -}}
{{- end -}}

{{/*
Resolves the effective sharePlanDir path.
If sharePlanDir is set, use it.
If sharePlanDirVolumeClaim.enabled is true and sharePlanDir is unset, default to /atlantis-plans.
Otherwise empty so ATLANTIS_SHARE_PLAN_DIR is not rendered.
*/}}
{{- define "atlantis.sharePlanDir" -}}
{{- if .Values.sharePlanDir -}}
{{- .Values.sharePlanDir -}}
{{- else if .Values.sharePlanDirVolumeClaim.enabled -}}
{{- "/atlantis-plans" -}}
{{- end -}}
{{- end -}}

{{/*
Compute a ConfigMap or Secret checksum from its data only, for the checksum/* pod annotations.
The full manifest carries the helm.sh/chart label, which changes on every chart version bump.
*/}}
{{- define "atlantis.configMapOrSecretContentHash" -}}
{{ pick (include (print .ctx.Template.BasePath .name) .ctx | fromYaml) "data" "stringData" | toYaml | sha256sum }}
{{- end -}}
